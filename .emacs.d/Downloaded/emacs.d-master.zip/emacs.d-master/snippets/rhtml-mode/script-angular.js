# -*- mode: snippet -*-
# name: <script src="angular.js">...</script>
# key: script
# contributor: Chen Bin <chenbin DOT sh AT gmail>
# --
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/angular.js/1.2.20/angular${1:.min}.js"></script>
