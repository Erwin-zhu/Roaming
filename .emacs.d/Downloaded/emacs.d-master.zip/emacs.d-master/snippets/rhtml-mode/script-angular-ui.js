# -*- mode: snippet -*-
# name: <script src="angularui.js">...</script>
# key: script
# contributor: Chen Bin <chenbin DOT sh AT gmail>
# --
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/angular-ui-bootstrap/0.11.2/ui-bootstrap-tpls${1:.min}.js"></script>